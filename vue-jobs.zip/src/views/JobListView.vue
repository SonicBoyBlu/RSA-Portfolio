<script setup>
import JobListView from "@/components/Jobs/JobList.vue";
</script>
<template>
  <JobListView />
</template>
